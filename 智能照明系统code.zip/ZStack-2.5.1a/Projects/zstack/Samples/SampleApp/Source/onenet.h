#ifndef _ONENET_H_
#define _ONENET_H_

#include "hal_types.h"



_Bool OneNet_DevLink(void);

//void OneNet_SendTempData(int t, int h);
void OneNet_SendTempData(unsigned short t);

void OneNet_SendLedAndBuzzerData(uint32 led1, int led2, int led3, int buzzer,uint8 Remote_dimming_control,uint8 Remote_self_dimming);

void OneNet_RevPro(unsigned char *cmd);

_Bool OneNet_PushData(const char* dst_devid, const char* data, unsigned int data_len);


extern void ESP8266_SendData(char* buff, int len);	
#endif
