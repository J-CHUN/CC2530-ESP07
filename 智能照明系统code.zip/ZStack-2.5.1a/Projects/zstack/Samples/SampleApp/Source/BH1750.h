#ifndef __BH1750_H  
#define __BH1750_H  
  
#include <ioCC2530.h>  
#include "OnBoard.h"  //�����õ���ͷ�ļ�

//����������P06��P07�ϣ����Ҫ�޸�IO�ڣ��޸����²���
/////////////////////�޸Ŀ�ʼ////////////////////////////////
#define SCL  P0_6
#define SDA  P0_7
#define SDA_W() (P1DIR |= 0x80 )
#define SDA_R() (P1DIR &=~0x80 )  

#define IO_INIT()            \
do{                             \
    P0SEL &= ~0xC0;             \
    P0DIR |=0xC0;               \
    SCL = 1;                   \
    SDA = 1;                   \
}while(0)                       \
/////////////////////�޸Ľ���////////////////////////////////

#define LIGHT_SCK_0()         (SCL=0)  
#define LIGHT_SCK_1()         (SCL=1)
#define LIGHT_DTA_0()         (SDA=0) 
#define LIGHT_DTA_1()         (SDA=1)
  
#define LIGHT_DTA()           (SDA)
#define LIGHT_SCK()           (SCL)

#define uint16      unsigned short


extern unsigned short lightInit(void);  
extern unsigned short get_light(void);  
  
#endif // __BH1750_H