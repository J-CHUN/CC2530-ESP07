#ifndef _MOTOR_H_
#define _MOTOR_H_
#include "hal_types.h"
extern void motorCtrl();

extern void Delay_ms(unsigned long h);
extern void motor_up(float n);
extern void motor_down(float n);
extern void initSensorPort();
extern float motorFlag; //0:ֹͣ  1:��ת   2:��ת
extern uint8 motorFlag1;
extern uint8 mflag;
#endif